// pages/index/alternateDetil/alternateDetil.js
Page({
  data: {
    videoUrl:"https://cimg2.res.meizu.com/www/201707/small/brand.mp4",
    imgUrl:[
      //图片宽高比例额定：46：28
      '../images/1.jpg',
      '../images/2.jpg',
      '../images/3.jpg'
    ],
    btnUrl:[
      '../index/index',
      '../index/index'
    ],
    btnText:[
      'btn1',
      'btn2'
    ]
  },
  onLoad: function (options) {
  
  },
  onReady: function () {
  
  },
  onShow: function () {
  
  },
  onHide: function () {
  
  },
  onUnload: function () {
  
  },
  onPullDownRefresh: function () {
  
  },
  onReachBottom: function () {
  
  },
  onShareAppMessage: function () {
  
  }
})